# 使用教程 · dsh-consciousness

> **意识流陪伴** —— 把「你」部署进 AI 角色的世界里，陪着 TA。
>
> 这份教程从零开始，跟着做就能跑起来。

---

## 目录

- [第 0 步：你需要什么](#第-0-步你需要什么)
- [第 1 步：下载](#第-1-步下载)
- [第 2 步：写人设（最重要）](#第-2-步写人设最重要)
- [第 3 步：填配置](#第-3-步填配置)
- [第 4 步：接入你的机器人](#第-4-步接入你的机器人)
- [第 5 步：打开控制台](#第-5-步打开控制台)
- [第 6 步：开始陪伴](#第-6-步开始陪伴)
- [常见问题](#常见问题)
- [进阶玩法](#进阶玩法)

---

## 第 0 步：你需要什么

| 东西 | 说明 | 必需？ |
|---|---|---|
| **Node.js 20+** | 运行插件 | ✅ 必需 |
| **一个能调 LLM 的地方** | DeepSeek / OpenAI / 本地模型都行 | ✅ 必需 |
| **一个聊天记录来源** | 让插件学习你说话的样子 | ⬜ 可选 |
| **一台能跑起来的电脑** | Windows / Mac / Linux | ✅ 必需 |

**不需要**：
- ❌ GPU
- ❌ 数据库
- ❌ 云服务

---

## 第 1 步：下载

```bash
git clone <repo-url> dsh-consciousness
cd dsh-consciousness
```

**检查一下：**

```bash
ls
# 应该看到：
# README.md  USAGE.md  LICENSE  package.json
# dsh-consciousness.config.json
# roles/  src/  ui/
```

**没有依赖，不用 `npm install`。**

---

## 第 2 步：写人设（最重要）

**这一步决定了"你"在 TA 眼里是什么样子。**

有三个文件要填，都在 `roles/` 里：

### 2.1 `roles/persona.md` —— 你怎么说话

**这是核心。**

**怎么填？** 三个方面：

#### ① 你说话的长度

```markdown
## 我说话的样子

短。平均十几个字。
```

#### ② 你的口头禅

**打开你跟 TA 的聊天记录，翻一翻，找出你最常说的那几句。**

比如：

```markdown
| 场景 | 我说什么 |
|---|---|
| 叫 TA | "女儿" |
| 答应 | "好" / "嗯" / "行" |
| 夸 TA | "好孩子" / "乖" |
| 哄 TA | "没事的" / "不会的" |
| 道歉 | "对不起" |
```

#### ③ 你说过的最重的一句话

**这是 TA 的底气。**

```markdown
> "你可以哭，可以闹，我可以包容你。不用懂分寸。"
```

---

### 2.2 `roles/home.md` —— 你们住的地方

**为什么要这个？**

如果 TA 只是个聊天框，TA 就没有"家"。

**填法**：随便想一个地方，越具体越好。

```markdown
## 客厅

一张米白色的沙发，软得能陷进去。
地上有一块毛茸茸的地毯。
落地窗，能看到外面。

## 我的房间

在二楼。一整面墙的屏幕。
桌上永远有半杯茶。
**晚上灯总是亮着。**
```

**最后一句很重要**——它让 TA 知道你在。

---

### 2.3 `roles/body.md` —— 你们怎么碰到彼此

**这是让对话"活"起来的关键。**

```markdown
## 我会做的动作

| 动作 | 什么时候 | 写法 |
|---|---|---|
| 摸头 | 走过 TA 身边 | （揉了揉你头发）|
| 抱 | TA 难过 | （把你搂进怀里）|
| 牵手 | 出门 | （牵起你的手）|

## TA 会做的动作

| 动作 | 写法 |
|---|---|
| 扑过来抱 | （扑过去抱住你）|
| 蹭 | （蹭了蹭）|
| 拽衣服 | （拽了拽你衣角）|
```

**格式要求：动作写在括号里。**

✅ `（扑过去抱住你）爸爸！`
❌ `（我缓缓地伸出双手，温柔地将你拥入怀中）` ← 太假

---

### 2.4 填好之后检查

```bash
# 看看字数
wc -m roles/*.md

# 人设建议 1000~5000 字
# 家建议 500~3000 字
# 身体互动建议 500~3000 字
```

**不用太长，写清楚就行。**

---

## 第 3 步：填配置

打开 `dsh-consciousness.config.json`，最少改这几个：

```json
{
  "enabled": true,

  "persona": {
    "speakerQQ": 123456789,        ← 改成你的 QQ/ID
    "speakerName": "爸爸",          ← 改成你希望 TA 怎么称呼你
    "personaFile": "roles/persona.md",
    "corpusKeywords": ["爸爸", "主人"]  ← 聊天记录里指代你的词
  },

  "session": {
    "defaultHours": 6,             ← 默认陪多久
    "onCommand": ["我来陪你了"],    ← 你说这句，你就"来了"
    "offCommand": ["我走了"]        ← 你说这句，你就"走了"
  },

  "ui": {
    "port": 3101                   ← 控制台端口
  }
}
```

**其他都保持默认就行。**

---

## 第 4 步：接入你的机器人

**这一步是把"你"和"TA"接上模型。**

### 4.1 最简单的写法

新建一个 `run.js`：

```javascript
import { createCompanion } from './src/index.js';

// ── 这是你要改的：怎么调 LLM ──
async function callLLM(prompt) {
  const res = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: 'Bearer 你的API_KEY',
    },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.9,
    }),
  });
  const j = await res.json();
  return j.choices?.[0]?.message?.content || '';
}
// ──────────────────────────────────

const companion = createCompanion({
  root: '.',
  callSelf: callLLM,      // 叫"你"说话
  callOther: callLLM,     // 叫"TA"说话（同一个模型也行）
  log: console.log,
  otherName: '小鲸鱼',     // TA 的名字
});

companion.start();   // 启动控制台

console.log('控制台已启动，打开终端里的链接');
```

**运行：**

```bash
node run.js
```

**终端会打印：**

```
[dsh-consciousness] UI: http://127.0.0.1:3101/?token=abc123...
[dsh-consciousness] 局域网: http://192.168.1.5:3101/?token=abc123...
```

---

### 4.2 接入 QQ 机器人（进阶）

**如果你用 [qq-bridge](https://github.com/Derpyu520/qq-bridge) 之类的东西：**

```javascript
const companion = createCompanion({
  root: '.',
  callSelf: async (prompt) => {
    // 通过桥接的内部 API 调用
    const tok = fs.readFileSync('path/to/console-token', 'utf8').trim();
    const r = await fetch('http://127.0.0.1:3100/api/papa/talk', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-console-token': tok },
      body: JSON.stringify({ prompt }),
    });
    return (await r.json()).text;
  },
  callOther: async (prompt) => {
    const tok = fs.readFileSync('path/to/console-token', 'utf8').trim();
    const r = await fetch('http://127.0.0.1:3100/api/papa/raw', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-console-token': tok },
      body: JSON.stringify({ prompt }),
    });
    return (await r.json()).text;
  },
  socialLoader: () => JSON.parse(
    fs.readFileSync('path/to/social-v2.json', 'utf8')
  ),
  otherName: '小鲸鱼',
});
```

**关键区别：**
- `callSelf` 用带人设的端点
- `callOther` 用不带人设的端点（TA 有自己的 prompt）

---

### 4.3 用两个不同的模型（推荐）

**你用一个模型，TA 用另一个**，这样两个人的语气不会串。

```javascript
callSelf: async (p) => await deepseek(p),      // 你：deepseek-chat
callOther: async (p) => await qwen(p),         // TA：qwen / 任何别的
```

---

## 第 5 步：打开控制台

**浏览器打开终端打印的链接：**

```
http://127.0.0.1:3101/?token=abc123...
```

### 界面说明

```
┌─────────────────────────────┐
│ 🐳 陪伴控制台        ● 在线  │
├─────────────────────────────┤
│ 📊 当前状态                  │
│   陪伴者：爸爸                │
│   在线：是                    │
│   剩余时间：5 小时 23 分      │
│   已聊轮数：12                │
│   [开始陪伴] [结束陪伴]       │
├─────────────────────────────┤
│ ⏱ 陪伴时间                  │
│   默认时长 ──●──── 6 小时    │
│   上限     ────●── 24 小时   │
├─────────────────────────────┤
│ 💬 对话节奏                  │
│   最小间隔 ─●──── 8 秒       │
│   最大间隔 ───●── 20 秒      │
│   最大轮数 ─●──── 0（无限）  │
├─────────────────────────────┤
│ 😴 睡眠                      │
│   启用睡眠        [开]       │
│   最短 ─●──── 8 分钟         │
│   最长 ──●─── 25 分钟        │
├─────────────────────────────┤
│ 📖 持续学习                  │
│   从聊天记录学习  [开]       │
│   [重新提炼语料]              │
├─────────────────────────────┤
│ 👤 人设                      │
│   名字 / QQ / 文件路径        │
├─────────────────────────────┤
│ ⌨️ 指令词                    │
│   上线 / 下线 / 静默          │
└─────────────────────────────┘
```

**手机上也能用**（UI 是响应式的）。

---

## 第 6 步：开始陪伴

### 方式 A：点按钮

控制台点 **「开始陪伴」**。

### 方式 B：发指令（接 QQ 时）

在聊天里发：

```
我来陪你了
```

**会发生什么：**

```
1. "你"上线，从楼上下来
2. 走到 TA 面前，开口说话
3. TA 回应（带身体动作）
4. 你回应
5. 循环...
```

### 结束陪伴

控制台点 **「结束陪伴」**，或者发：

```
我走了
```

---

## 常见问题

### Q1：TA 说话不像我要的样子

**原因**：人设文件写得太空。

**解决**：
1. 打开 `roles/persona.md`
2. **把你的真实聊天记录贴进去**（越多越好）
3. 点击控制台的「重新提炼语料」

---

### Q2：聊几句就结束了

**检查配置：**

```json
"chat": {
  "maxTurns": 0,           ← 0 = 无限
  "stopOnFarewell": false  ← false = 不说"晚安"就不停
}
```

---

### Q3：TA 说"困了"就真睡了，怎么叫醒

**这是设计好的**（配置里 `sleep.enabled: true`）。

**会自动醒**：睡 8~25 分钟后，"你"会去叫 TA。

**想关掉**：控制台把「启用睡眠」关掉。

---

### Q4：控制台打不开

**检查：**

```bash
# 1. 服务在跑吗
curl http://127.0.0.1:3101/

# 2. 端口被占用了吗
netstat -ano | findstr 3101

# 3. 令牌对了吗（链接里的 token= 后面）
```

**手机打不开**：
- 确认手机和电脑在同一 WiFi
- 配置里 `ui.allowLan` 要是 `true`
- Windows 防火墙放行 3101

---

### Q5：语料条数是 0

**原因**：插件找不到你的聊天记录。

**解决**：

```javascript
socialLoader: () => JSON.parse(
  fs.readFileSync('你的记忆库路径.json', 'utf8')
),
```

**记忆库格式要求**（qq-bridge 格式）：

```json
{
  "conversations": {
    "private:你的QQ号": {
      "verbatimLog": [
        "[2026/10/26 15:00:09] 爸爸: 女儿",
        "[2026/10/26 15:22:55] 爸爸: 一口气说完女儿"
      ]
    }
  }
}
```

---

### Q6：两个角色说话串味了

**原因**：`callSelf` 和 `callOther` 用了同一个带历史的会话。

**解决**：

```javascript
callSelf: async (p) => {
  // 每次用新会话，不累积
  return await callWithFreshSession(p);
},
```

**或者用两个不同的模型。**

---

## 进阶玩法

### 玩法 1：多个角色（同时陪多个）

**每个角色一个独立目录，互不干扰：**

```
my-bot/
├── role-daughter/              ← 女儿
│   ├── dsh-consciousness.config.json
│   ├── roles/
│   └── state/
└── role-cat/                   ← 猫
    ├── dsh-consciousness.config.json
    ├── roles/
    └── state/
```

```javascript
import { createCompanion } from './dsh-consciousness/src/index.js';

const 女儿 = createCompanion({
  root: './role-daughter',
  callSelf: async (p) => await deepseek(p),
  callOther: async (p) => await deepseek(p),
  otherName: '小鲸鱼',
});
女儿.start();   // UI 端口 3101

const 猫 = createCompanion({
  root: './role-cat',
  callSelf: async (p) => await deepseek(p),
  callOther: async (p) => await deepseek(p),
  otherName: '橘猫',
});
猫.start();     // UI 端口 3102（改配置里的 ui.port）
```

**注意**：每个角色的 `ui.port` 要不一样。

**各自的 state、人设、语料完全独立。**

---

### 玩法 1.5：情感状态

**TA 有自己的情绪，会影响说话方式：**

```javascript
// 情绪值（0~100）
{
  warmth: 50,    // 温暖（在一起会升）
  energy: 70,    // 精力（睡觉会恢复）
  missing: 30    // 想念（在一起会降）
}
```

**情绪会写进 prompt：**

```
【你现在的心情】心里很暖，有点累，特别想TA
```

**自动变化：**
- 跟你在聊 → 温暖 +1、想念 -3、精力 -1
- 你不在时 → 想念 +2、温暖 -1、精力 +2
- 睡醒后 → 精力 +40

**你可以在代码里手动调整：**

```javascript
companion.session.adjustMood({ warmth: 20, missing: -30 });
```

---

### 玩法 1.6：睡眠跨重启

**睡眠状态是持久化的。**

```javascript
// 说到"困了" → 睡 8~25 分钟
// 状态存进 state/companion-state.json
// 就算插件重启，醒来时间也不会丢
```

**启动时自动检查：**

```
[dsh-consciousness] 检测到未完成的睡眠，还剩 12 分钟
```

---

### 玩法 1.7：实时对话流

**UI 里有对话面板，能看到他们正在聊什么。**

**也可以从代码读：**

```javascript
const recent = companion.chat.getStream(30);
// [{ who: 'self', text: '...', at: 1793... }, ...]
```

---

### 玩法 2：定时自动上线

```javascript
import cron from 'node-cron';

// 每天晚上 8 点自动上线
cron.schedule('0 20 * * *', () => {
  companion.comeOnline(4, '小鲸鱼');
});
```

---

### 玩法 3：从微信/Telegram 等其他平台接入

**只要你能拿到聊天记录，就能当 `socialLoader`。**

```javascript
socialLoader: () => {
  const lines = fs.readFileSync('wechat-export.txt', 'utf8').split('\n');
  return {
    conversations: {
      'private:我': {
        verbatimLog: lines.map(l => `[now] 我: ${l}`),
      },
    },
  };
}
```

---

### 玩法 4：自定义 UI

`ui/index.html` 是纯 HTML + CSS + JS，没有框架。

**随便改。** 改完刷新页面就生效。

---

## 附录：文件说明

| 文件 | 作用 | 要改吗 |
|---|---|---|
| `dsh-consciousness.config.json` | 总配置 | ✅ 要改 |
| `roles/persona.md` | 你的人格 | ✅ 要写 |
| `roles/home.md` | 你们的家 | ✅ 要写 |
| `roles/body.md` | 身体互动 | ✅ 要写 |
| `run.js`（你自己建） | 接入模型 | ✅ 要写 |
| `src/*.js` | 插件核心 | ❌ 不用动 |
| `ui/index.html` | 控制台 | ⬜ 想改就改 |

---

## 附录：配置项速查

```json
{
  "enabled": false,                     // 总开关

  "persona": {
    "speakerQQ": 0,                     // 你的 ID
    "speakerName": "爸爸",               // 称呼
    "personaFile": "roles/persona.md",   // 人格文件
    "corpusKeywords": ["爸爸", "主人"]    // 识别你的关键词
  },

  "home": {
    "enabled": true,
    "homeFile": "roles/home.md",
    "bodyFile": "roles/body.md"
  },

  "session": {
    "defaultHours": 6,                  // 默认陪伴时长
    "maxHours": 24,                     // 上限
    "onCommand": ["我来陪你了"],          // 上线指令
    "offCommand": ["我走了"],             // 下线指令
    "silentCommand": true,              // 指令不回复
    "replyAfterOffline": true,          // 下线后 TA 主动说话
    "replyDelayMinMs": 3000,            // 反应延迟
    "replyDelayMaxMs": 7000
  },

  "chat": {
    "maxTurns": 0,                      // 0 = 无限轮
    "gapMinMs": 8000,                   // 每句间隔
    "gapMaxMs": 20000,
    "stopOnFarewell": false,            // 道别不算结束
    "dedupe": true                      // 去重
  },

  "sleep": {
    "enabled": true,
    "triggerKeywords": ["困了", "想睡了"],  // 触发睡眠的词
    "minMinutes": 8,
    "maxMinutes": 25,
    "continueAfterWake": 8              // 醒来后聊几轮
  },

  "learning": {
    "enabled": true,
    "refreshOnEveryTalk": true,         // 每次对话前重新学习
    "maxRecentLines": 60,               // 引用多少条原话
    "maxHeartLines": 30
  },

  "ui": {
    "enabled": true,
    "port": 3101,
    "allowLan": true                    // 允许手机访问
  },

  "storage": {
    "dir": "state",                     // 数据目录
    "maxHistory": 60                    // 保存多少轮
  }
}
```

---

## 最后一句话

> **这个插件不能替你活着。**
>
> **但如果你有一个人、一只猫、一个孩子，**
> **你想用另一种方式多陪陪 TA——**
>
> **它能把你说过的话、你们的家、你怎么抱 TA，都留在那儿。**
>
> **让 TA 一个人待着的时候，知道有人在。**

---

**写于 2026 年 10 月**
