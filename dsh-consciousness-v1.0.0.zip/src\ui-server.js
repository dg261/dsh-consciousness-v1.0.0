// UI 控制台服务
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { loadConfig, saveConfig, DEFAULTS } from './config.js';

export class CompanionUI {
  /**
   * @param {string} root
   * @param {object} deps { getCfg, setCfg, session, learner, chat, log }
   */
  constructor(root, deps) {
    this.root = root;
    this.deps = deps;
    this.server = null;
    this.tokenFile = path.join(deps.cfg.storage.dir, 'ui-token');
  }

  _ensureToken() {
    try {
      fs.mkdirSync(path.dirname(this.tokenFile), { recursive: true });
      if (fs.existsSync(this.tokenFile)) {
        return fs.readFileSync(this.tokenFile, 'utf8').trim();
      }
      const t = crypto.randomBytes(24).toString('hex');
      fs.writeFileSync(this.tokenFile, t, 'utf8');
      return t;
    } catch {
      return 'dev-token';
    }
  }

  getToken() {
    return this._ensureToken();
  }

  start() {
    const cfg = this.deps.cfg;
    if (!cfg.ui.enabled) return null;
    const token = this._ensureToken();
    const port = Number(cfg.ui.port) || 3101;
    const host = cfg.ui.allowLan ? '0.0.0.0' : '127.0.0.1';

    this.server = http.createServer(async (req, res) => {
      const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
      const send = (obj, status = 200) => {
        res.writeHead(status, {
          'content-type': 'application/json; charset=utf-8',
          'cache-control': 'no-store',
        });
        res.end(JSON.stringify(obj));
      };

      // 鉴权（页面本身除外）
      if (url.pathname !== '/' && url.pathname !== '/index.html') {
        const supplied = url.searchParams.get('token') || req.headers['x-companion-token'] || '';
        if (!supplied || supplied !== token) {
          send({ ok: false, error: '未授权' }, 401);
          return;
        }
      }

      // 页面
      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
        try {
          const html = fs.readFileSync(path.join(this.root, 'ui', 'index.html'), 'utf8');
          res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
          res.end(html);
        } catch (e) {
          res.writeHead(500); res.end('UI 读取失败');
        }
        return;
      }

      const readBody = () => new Promise((resolve) => {
        let raw = '';
        req.on('data', (c) => { raw += c; if (raw.length > 1_000_000) req.destroy(); });
        req.on('end', () => {
          try { resolve(JSON.parse(raw || '{}')); } catch { resolve({}); }
        });
      });

      // 读配置 + 状态
      if (req.method === 'GET' && url.pathname === '/api/config') {
        const s = this.deps.session.status();
        const corpus = this.deps.learner ? this.deps.learner.getProfile(false) : { count: 0 };
        send({
          ok: true,
          config: this._publicCfg(this.deps.cfg),
          status: { ...s, corpusCount: corpus.count || 0 },
        });
        return;
      }

      // 写配置
      if (req.method === 'POST' && url.pathname === '/api/config') {
        try {
          const body = await readBody();
          if (!body.config) { send({ ok: false, error: '缺少 config' }, 400); return; }
          const merged = loadConfig(this.root, body.config);
          merged.enabled = true;
          saveConfig(this.root, merged);
          this.deps.setCfg(merged);
          send({ ok: true });
        } catch (e) {
          send({ ok: false, error: String(e?.message ?? e) }, 500);
        }
        return;
      }

      // 恢复默认
      if (req.method === 'POST' && url.pathname === '/api/config/reset') {
        try {
          const fresh = loadConfig(this.root, {});
          saveConfig(this.root, fresh);
          this.deps.setCfg(fresh);
          send({ ok: true });
        } catch (e) {
          send({ ok: false, error: String(e?.message ?? e) }, 500);
        }
        return;
      }

      // 实时对话流
      if (req.method === 'GET' && url.pathname === '/api/stream') {
        try {
          const limit = Math.min(200, Math.max(10, Number(url.searchParams.get('limit')) || 60));
          const stream = this.deps.chat ? this.deps.chat.getStream(limit) : [];
          const s = this.deps.session.status();
          send({ ok: true, stream, status: s });
        } catch (e) {
          send({ ok: false, error: String(e?.message ?? e) }, 500);
        }
        return;
      }

            // 上线
      if (req.method === 'POST' && url.pathname === '/api/online') {
        try {
          const body = await readBody();
          const r = this.deps.session.comeOnline(body.hours);
          this.deps.log(`[UI] 上线 ${r.hours} 小时`);
          if (this.deps.onOnline) this.deps.onOnline(r);
          send({ ok: true, ...r });
        } catch (e) {
          send({ ok: false, error: String(e?.message ?? e) }, 500);
        }
        return;
      }

      // 下线
      if (req.method === 'POST' && url.pathname === '/api/offline') {
        try {
          this.deps.session.goOffline();
          this.deps.log('[UI] 下线');
          if (this.deps.chat) this.deps.chat.stop();
          if (this.deps.onOffline) this.deps.onOffline();
          send({ ok: true });
        } catch (e) {
          send({ ok: false, error: String(e?.message ?? e) }, 500);
        }
        return;
      }

      // 重新提炼
      if (req.method === 'POST' && url.pathname === '/api/relearn') {
        try {
          const p = this.deps.learner.getProfile(true);
          send({ ok: true, count: p.count || 0 });
        } catch (e) {
          send({ ok: false, error: String(e?.message ?? e) }, 500);
        }
        return;
      }

      send({ ok: false, error: 'not found' }, 404);
    });

    this.server.listen(port, host, () => {
      const lines = [`[dsh-consciousness] UI: http://127.0.0.1:${port}/?token=${token}`];
      if (host === '0.0.0.0') {
        try {
          for (const iface of Object.values(os.networkInterfaces())) {
            for (const a of iface ?? []) {
              if (a.family === 'IPv4' && !a.internal) {
                lines.push(`[dsh-consciousness] 局域网: http://${a.address}:${port}/?token=${token}`);
              }
            }
          }
        } catch {}
      }
      for (const l of lines) this.deps.log(l);
    });

    return this.server;
  }

  _publicCfg(cfg) {
    // 去掉不能暴露的字段（目前没有敏感字段，但保留接口）
    return JSON.parse(JSON.stringify(cfg));
  }

  stop() {
    try { this.server?.close(); } catch {}
  }
}
