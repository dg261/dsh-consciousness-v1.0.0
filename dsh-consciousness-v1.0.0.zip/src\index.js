// dsh-consciousness —— 主入口
//
// 把「你」以一种永久陪伴的形态部署进 AI 角色身边。
//
// 用法（作为 DSH 插件）：
//   import { createCompanion } from 'dsh-consciousness';
//   const companion = createCompanion({
//     root: '/path/to/plugin',
//     callSelf: async (prompt) => ...,
//     callOther: async (prompt) => ...,
//     socialLoader: () => JSON.parse(fs.readFileSync('state/social-v2.json', 'utf8')),
//     log: console.log,
//   });
//   await companion.start();
//
// 或独立运行：
//   node src/index.js
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadConfig } from './config.js';
import { CompanionSession } from './session.js';
import { CorpusLearner } from './learner.js';
import { PromptBuilder } from './prompt.js';
import { ChatEngine } from './chat.js';
import { CompanionUI } from './ui-server.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 创建一个陪伴实例
 * @param {object} opts
 * @param {string} [opts.root] 插件根目录（默认自动推断）
 * @param {(prompt:string)=>Promise<string>} opts.callSelf 叫"陪伴者"说话
 * @param {(prompt:string)=>Promise<string>} opts.callOther 叫"对方"说话
 * @param {()=>object|null} [opts.socialLoader] 读记忆库
 * @param {(msg:string)=>void} [opts.log]
 * @param {object} [opts.configOverrides]
 */
export function createCompanion(opts = {}) {
  const root = opts.root || path.resolve(__dirname, '..');
  const log = opts.log || ((m) => console.log(m));

  const cfg = loadConfig(root, opts.configOverrides || {});

  if (typeof opts.callSelf !== 'function' || typeof opts.callOther !== 'function') {
    throw new Error('[dsh-consciousness] 必须提供 callSelf 和 callOther 两个模型调用函数');
  }

  const session = new CompanionSession(cfg);
  const learner = new CorpusLearner(cfg, root, opts.socialLoader);
  const prompts = new PromptBuilder(cfg, root, learner, session);
  const chat = new ChatEngine(cfg, session, prompts, opts.callSelf, opts.callOther, log);

  // ★ 启动时检查：有没有跨重启的睡眠还在进行
  const bootSleep = session.checkSleepOnBoot();
  if (bootSleep.had) {
    if (bootSleep.stillSleeping) {
      log(`[dsh-consciousness] 检测到未完成的睡眠，还剩 ${Math.round(bootSleep.remainMs/60000)} 分钟`);
    } else {
      log('[dsh-consciousness] 睡眠已在重启期间结束');
    }
  }

  let currentCfg = cfg;

  const ui = new CompanionUI(root, {
    get cfg() { return currentCfg; },
    setCfg(c) { currentCfg = c; },
    session,
    learner,
    chat,
    log,
    onOnline: (r) => {
      // UI 点"开始陪伴" → 启动对话
      const otherName = opts.otherName || '对方';
      chat.start(otherName).then((res) => {
        log(`[dsh-consciousness] 对话结束：${res.stopReason || res.error}`);
      }).catch(() => {});
    },
    onOffline: () => log('[dsh-consciousness] 已下线'),
  });

  return {
    session,
    learner,
    prompts,
    chat,
    ui,
    /** 启动 UI */
    start() {
      if (currentCfg.ui.enabled) ui.start();
      return this;
    },
    /** 上线并开始聊天 */
    async comeOnline(hours, otherName) {
      const r = session.comeOnline(hours);
      log(`[dsh-consciousness] 上线 ${r.hours} 小时`);
      const res = await chat.start(otherName || opts.otherName || '对方');
      return { ...r, chat: res };
    },
    /** 下线 */
    goOffline() {
      session.goOffline();
      chat.stop();
      log('[dsh-consciousness] 下线');
    },
    /** 状态 */
    status() {
      return session.status();
    },
    /** 停止（关 UI） */
    stop() {
      chat.stop();
      ui.stop();
    },
  };
}

// ── 独立运行（带一个简单的 CLI 测试）────────────────────
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  const root = path.resolve(__dirname, '..');
  console.log('[dsh-consciousness] 独立模式启动');
  console.log('  根目录:', root);

  const cfg = loadConfig(root, {});
  const session = new CompanionSession(cfg);
  const learner = new CorpusLearner(cfg, root, () => null);
  const prompts = new PromptBuilder(cfg, root, learner);

  console.log('  状态:', JSON.stringify(session.status()));
  console.log('  语料条数:', learner.getProfile(true).count);
  console.log('');
  console.log('  提示：独立模式没有模型，只验证配置和状态。');
  console.log('  要真正跑对话，请作为 DSH 插件使用（提供 callSelf / callOther）。');

  if (cfg.ui.enabled) {
    const ui = new CompanionUI(root, {
      get cfg() { return cfg; },
      setCfg() {},
      session, learner, chat: null,
      log: (m) => console.log(m),
    });
    ui.start();
    console.log('  UI 已启动，按 Ctrl+C 退出');
  }
}
