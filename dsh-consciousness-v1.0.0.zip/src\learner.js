// 持续学习：从聊天记录提炼"说话状态"画像
import fs from 'node:fs';
import path from 'node:path';

export class CorpusLearner {
  /**
   * @param {object} cfg
   * @param {string} root 插件根目录
   * @param {(file:string)=>string|null} socialLoader 外部注入：读记忆库文件的函数
   */
  constructor(cfg, root, socialLoader) {
    this.cfg = cfg;
    this.root = root;
    this.socialLoader = socialLoader || (() => null);
    this.cacheFile = path.join(cfg.storage.dir, 'corpus-cache.json');
    this.cache = null;
  }

  /** 从记忆库里提取"我"说过的话 */
  extractLines() {
    const ownerQQ = String(this.cfg.persona.speakerQQ || '');
    const keywords = this.cfg.persona.corpusKeywords || [];
    const data = this.socialLoader();
    if (!data) return [];

    const lines = [];
    const conversations = data.conversations || {};
    for (const [key, conv] of Object.entries(conversations)) {
      const log = Array.isArray(conv?.verbatimLog) ? conv.verbatimLog : [];
      for (const item of log) {
        const s = String(item);
        // 只从"我"的私聊里取，或者从带关键词的行里取
        const isOwnerConv = ownerQQ && key === `private:${ownerQQ}`;
        const m = s.match(/\]\s*([^:：]+)[:：]\s*(.+)$/);
        if (!m) continue;
        const who = m[1].trim();
        const body = m[2].trim();
        if (!body) continue;
        if (/^\[(图片|表情|语音|视频|文件)/.test(body)) continue;

        const matched = isOwnerConv || keywords.some((k) => who.includes(k));
        if (!matched) continue;
        lines.push(body);
      }
    }
    return lines;
  }

  /** 分析语料 → 画像 */
  analyze() {
    const lines = this.extractLines();
    const n = lines.length;
    if (n === 0) {
      return { generatedAt: Date.now(), count: 0, empty: true, summary: '' };
    }

    const lens = lines.map((t) => t.length);
    const avgLen = lens.reduce((a, b) => a + b, 0) / n;
    const shortCount = lens.filter((l) => l <= 5).length;

    // 高频词（2-3 字）
    const freq = new Map();
    for (const t of lines) {
      const clean = t.replace(/@[^\s]+/g, '').replace(/\[[^\]]+\]/g, '');
      for (let i = 0; i < clean.length - 1; i++) {
        for (const len of [2, 3]) {
          if (i + len > clean.length) continue;
          const w = clean.slice(i, i + len);
          if (!/^[\u4e00-\u9fa5]+$/.test(w)) continue;
          freq.set(w, (freq.get(w) || 0) + 1);
        }
      }
    }
    const topWords = [...freq.entries()]
      .filter(([, c]) => c >= 3)
      .sort((a, b) => b[1] - a[1])
      .slice(0, this.cfg.learning.topWordsLimit)
      .map(([w, c]) => `${w}(${c})`);

    const recent = lines.slice(-this.cfg.learning.maxRecentLines);
    const heartLines = lines
      .filter((t) => /女儿|孩子|乖|陪|想你|难过|开心|累|爱|别怕|没事/.test(t))
      .slice(-this.cfg.learning.maxHeartLines);

    const parts = [
      `【他从 ${n} 句话里提炼的说话状态】`,
      '',
      `平均句长：${avgLen.toFixed(1)} 字（${shortCount} 句在 5 字以内，占 ${Math.round((shortCount / n) * 100)}%）`,
      '',
      `高频用语：${topWords.join('、')}`,
      '',
      '【他最近真正说过的话（照这个语感说话）】',
      ...recent.map((t) => `- ${t}`),
    ];
    if (heartLines.length) {
      parts.push('', '【他最像"家长"的那些话】', ...heartLines.map((t) => `- ${t}`));
    }

    return {
      generatedAt: Date.now(),
      count: n,
      avgLen: Number(avgLen.toFixed(1)),
      topWords,
      summary: parts.join('\n'),
      recent,
      empty: false,
    };
  }

  /** 读画像（有缓存就用缓存） */
  getProfile(force = false) {
    if (!force && this.cache) return this.cache;
    if (!force) {
      try {
        let raw = fs.readFileSync(this.cacheFile, 'utf8');
        if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1);
        this.cache = JSON.parse(raw);
        return this.cache;
      } catch {}
    }
    const profile = this.analyze();
    try {
      fs.mkdirSync(this.cfg.storage.dir, { recursive: true });
      fs.writeFileSync(this.cacheFile, JSON.stringify(profile, null, 2), 'utf8');
    } catch {}
    this.cache = profile;
    return profile;
  }
}
