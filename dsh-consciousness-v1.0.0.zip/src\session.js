// 陪伴会话：上线/下线/状态/持久化/睡眠/情绪
import fs from 'node:fs';
import path from 'node:path';

export class CompanionSession {
  /**
   * @param {object} cfg 已加载的配置
   */
  constructor(cfg) {
    this.cfg = cfg;
    this.stateFile = path.join(cfg.storage.dir, 'companion-state.json');
    this.state = this._load();
  }

  _load() {
    try {
      let raw = fs.readFileSync(this.stateFile, 'utf8');
      if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1);
      const s = JSON.parse(raw);
      if (!Array.isArray(s.history)) s.history = [];
      // 补全新增字段
      if (typeof s.sleepUntil !== 'number') s.sleepUntil = 0;
      if (!s.mood || typeof s.mood !== 'object') {
        s.mood = { warmth: 50, energy: 70, missing: 30 };
      }
      return s;
    } catch {
      return {
        history: [],
        lastAt: 0,
        active: false,
        sleepUntil: 0,
        mood: { warmth: 50, energy: 70, missing: 30 },
      };
    }
  }

  _save() {
    try {
      fs.mkdirSync(path.dirname(this.stateFile), { recursive: true });
      if (this.state.history.length > this.cfg.storage.maxHistory * 2) {
        this.state.history = this.state.history.slice(-this.cfg.storage.maxHistory * 2);
      }
      fs.writeFileSync(this.stateFile, JSON.stringify(this.state, null, 2), 'utf8');
    } catch {}
  }

  /** 上线 */
  comeOnline(hours) {
    const h = Math.min(
      this.cfg.session.maxHours,
      Math.max(0.01, Number(hours) || this.cfg.session.defaultHours),
    );
    const now = Date.now();
    this.state.active = true;
    this.state.onlineAt = now;
    this.state.expiresAt = now + h * 3600 * 1000;
    this._save();
    return { active: true, onlineAt: now, expiresAt: this.state.expiresAt, hours: h };
  }

  /** 下线 */
  goOffline() {
    this.state.active = false;
    this.state.offlineAt = Date.now();
    this._save();
    return { active: false };
  }

  /** 当前是否在线 */
  isOnline() {
    if (!this.state.active) return { online: false, reason: '不在线' };
    if (this.state.expiresAt && Date.now() > this.state.expiresAt) {
      this.state.active = false;
      this._save();
      return { online: false, reason: '陪的时间到了' };
    }
    return {
      online: true,
      onlineAt: this.state.onlineAt,
      expiresAt: this.state.expiresAt,
      remainMs: this.state.expiresAt - Date.now(),
    };
  }

  /** 记录一轮对话 */
  recordTurn(mineText, theirsText) {
    const now = Date.now();
    this.state.history.push({ role: 'self', text: String(mineText).slice(0, 500), at: now });
    this.state.history.push({ role: 'other', text: String(theirsText).slice(0, 500), at: now });
    this.state.lastAt = now;
    this._save();
  }

  /** 清空对话历史（人设不动） */
  resetHistory() {
    this.state.history = [];
    this.state.lastAt = 0;
    this._save();
  }

  /** 状态汇总 */
  status() {
    const on = this.isOnline();
    const turns = Math.floor(this.state.history.length / 2);
    return {
      online: on.online,
      reason: on.reason,
      onlineAt: on.onlineAt,
      expiresAt: on.expiresAt,
      remainMs: on.remainMs,
      turns,
      lastAt: this.state.lastAt,
      sleeping: this.isSleeping(),
      mood: this.state.mood,
    };
  }

  // ── 睡眠（持久化：重启不丢）──────────────────────────

  /** 开始睡觉：记录唤醒时间到 state */
  startSleep(minutes) {
    const ms = Math.max(1, Number(minutes) || 10) * 60 * 1000;
    this.state.sleepUntil = Date.now() + ms;
    this._save();
    return { sleepUntil: this.state.sleepUntil, minutes: Math.round(ms / 60000) };
  }

  /** 是否在睡 */
  isSleeping() {
    return this.state.sleepUntil > Date.now();
  }

  /** 剩余睡眠毫秒 */
  sleepRemainMs() {
    return Math.max(0, this.state.sleepUntil - Date.now());
  }

  /** 醒来（清掉 sleepUntil） */
  wakeUp() {
    this.state.sleepUntil = 0;
    this._save();
    return { woken: true, sleepMs: 0 };
  }

  /** 启动时检查：有没有跨重启的睡眠还在进行 */
  checkSleepOnBoot() {
    if (!this.state.sleepUntil) return { had: false };
    if (this.state.sleepUntil > Date.now()) {
      return {
        had: true,
        stillSleeping: true,
        remainMs: this.state.sleepUntil - Date.now(),
      };
    }
    // 睡眠时间已过（进程重启期间睡完了）
    const sleptMs = Date.now() - (this.state.sleepUntil - 900000);
    this.state.sleepUntil = 0;
    this._save();
    return { had: true, stillSleeping: false, sleptMs };
  }

  // ── 情绪 ────────────────────────────────────────────

  /**
   * 调整情绪值（0~100）
   * @param {{warmth?:number, energy?:number, missing?:number}} delta
   */
  adjustMood(delta) {
    const m = this.state.mood;
    for (const k of ['warmth', 'energy', 'missing']) {
      if (typeof delta[k] === 'number') {
        m[k] = Math.max(0, Math.min(100, (m[k] || 50) + delta[k]));
      }
    }
    this._save();
    return m;
  }

  /** 情绪的自然变化（每轮调用） */
  tickMood(isWithYou) {
    const m = this.state.mood;
    if (isWithYou) {
      // 在一起：温暖上升、想念下降、精力缓慢下降
      m.warmth = Math.min(100, m.warmth + 1);
      m.missing = Math.max(0, m.missing - 3);
      m.energy = Math.max(0, m.energy - 1);
    } else {
      // 不在一起：想念累积、温暖缓降
      m.missing = Math.min(100, m.missing + 2);
      m.warmth = Math.max(0, m.warmth - 1);
      m.energy = Math.min(100, m.energy + 2);
    }
    this._save();
    return m;
  }

  /** 情绪文字描述（注入 prompt 用） */
  moodText() {
    const m = this.state.mood;
    const parts = [];
    if (m.warmth >= 70) parts.push('心里很暖');
    else if (m.warmth >= 40) parts.push('心里平平的');
    else parts.push('心里有点空');

    if (m.energy >= 70) parts.push('精神还不错');
    else if (m.energy >= 40) parts.push('有点累');
    else parts.push('很困');

    if (m.missing >= 70) parts.push('特别想TA');
    else if (m.missing >= 40) parts.push('有点想TA');

    return parts.join('，');
  }
}
