// 对话引擎：主动开口 → 自然聊 → 睡觉 → 醒来 → 继续
export class ChatEngine {
  /**
   * @param {object} cfg
   * @param {CompanionSession} session
   * @param {PromptBuilder} prompts
   * @param {(prompt:string)=>Promise<string>} callModelSelf 叫我（陪伴者）说话
   * @param {(prompt:string)=>Promise<string>} callModelOther 叫对方说话
   * @param {(msg:string)=>void} log
   */
  constructor(cfg, session, prompts, callModelSelf, callModelOther, log) {
    this.cfg = cfg;
    this.session = session;
    this.prompts = prompts;
    this.callSelf = callModelSelf;
    this.callOther = callModelOther;
    this.log = log || (() => {});
    this.running = false;
    this.sleepTimer = null;
    /** 实时对话流（最多 200 条），供 UI 读取 */
    this.stream = [];
  }

  /** 往对话流里加一条 */
  _emit(who, text) {
    this.stream.push({ who, text: String(text).slice(0, 1000), at: Date.now() });
    if (this.stream.length > 200) this.stream = this.stream.slice(-200);
  }

  /** 取最近 N 条（供 UI） */
  getStream(limit = 60) {
    return this.stream.slice(-limit);
  }

  _sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  _randGap() {
    const { gapMinMs, gapMaxMs } = this.cfg.chat;
    return gapMinMs + Math.floor(Math.random() * Math.max(1, gapMaxMs - gapMinMs));
  }

  /** 开始 */
  async start(otherName = '对方') {
    if (this.running) return { ok: false, error: '已经在聊了' };
    this.running = true;
    const history = [];
    const seen = new Set();
    let stopReason = '';

    try {
      // ① 我主动开口
      const openingPrompt = this.prompts.buildSelfPrompt(
        '（你从楼上下来，走到客厅，TA 在那儿。你跟 TA 说句话。）',
      );
      const opening = await this.callSelf(openingPrompt);
      if (!opening) throw new Error('开场失败');
      history.push({ role: 'self', text: opening });
      seen.add(opening);
      this.session.tickMood(true);   // 在一起，温暖+
      this.session.recordTurn('（来了）', opening);
      this.log(`我：${opening}`); this._emit('self', opening);;

      // ② 循环
      const maxTurns = this.cfg.chat.maxTurns > 0 ? this.cfg.chat.maxTurns : Infinity;
      let turn = 0;

      while (turn < maxTurns) {
        const on = this.session.isOnline();
        if (!on.online) { stopReason = '下线了'; break; }
        turn++;

        await this._sleep(this._randGap());

        // 对方回应
        const lastSelf = history[history.length - 1].text;
        let otherReply = '';
        try {
          otherReply = await this.callOther(
            this.prompts.buildOtherPrompt(lastSelf, otherName, history),
          );
        } catch { continue; }
        if (!otherReply) continue;
        if (this.cfg.chat.dedupe && seen.has(otherReply)) continue;
        seen.add(otherReply);
        history.push({ role: 'other', text: otherReply });
        this.session.recordTurn(otherReply, lastSelf);
        this.log(`${otherName}：${otherReply}`); this._emit('other', otherReply);;

        // 检查是否要睡觉
        // ★ 情绪：和 TA 在一起，温暖+，想念-
        this.session.tickMood(true);

        if (this.cfg.sleep.enabled && this._wantsSleep(otherReply)) {
          const mins = this.cfg.sleep.minMinutes
            + Math.floor(Math.random() * Math.max(1, this.cfg.sleep.maxMinutes - this.cfg.sleep.minMinutes));
          // ★ 持久化睡眠：写进 state，重启也不丢
          this.session.startSleep(mins);
          this.log(`${otherName}睡着了（${mins} 分钟，已持久化）`);
          this.session.recordTurn(otherReply, '（在旁边看着 TA 睡着）');
          this.sleepTimer = setTimeout(() => {
            this.session.wakeUp();
            this._wakeUp(otherName, mins).catch((e) => this.log('醒来失败：' + (e?.message ?? e)));
          }, mins * 60 * 1000);
          stopReason = `${otherName}睡了（${mins} 分钟后醒）`;
          break;
        }

        await this._sleep(this._randGap());

        // 我再回应
        let selfReply = '';
        try {
          selfReply = await this.callSelf(
            this.prompts.buildSelfPrompt(otherReply, history),
          );
        } catch { continue; }
        if (!selfReply) continue;
        if (this.cfg.chat.dedupe && seen.has(selfReply)) continue;
        seen.add(selfReply);
        history.push({ role: 'self', text: selfReply });
        this.session.recordTurn(otherReply, selfReply);
        this.log(`我：${selfReply}`); this._emit('self', selfReply);;
      }

      if (!stopReason) stopReason = '自然结束';
      this.log(`对话结束：${stopReason}`);
      return { ok: true, turns: Math.floor(history.length / 2), stopReason, history };
    } catch (e) {
      return { ok: false, error: String(e?.message ?? e), history };
    } finally {
      this.running = false;
    }
  }

  _wantsSleep(text) {
    const s = String(text || '').trim();
    return this.cfg.sleep.triggerKeywords.some((k) => s.includes(k));
  }

  /** 叫醒 TA，然后继续聊 */
  async _wakeUp(otherName, sleptMinutes) {
    if (!this.session.isOnline().online) {
      this.log(`${otherName}醒了，但已经下线了`);
      return;
    }
    const wakePrompt = this.prompts.buildSelfPrompt(
      `（TA 刚才睡着了，睡了 ${sleptMinutes} 分钟。你走过去，蹲下来看 TA。）`,
    );
    const selfWake = await this.callSelf(wakePrompt);
    this.log(`我：${selfWake}`); this._emit('self', selfWake);;

    const otherWakePrompt = this.prompts.buildOtherPrompt(
      selfWake,
      otherName,
      [],
    ) + `\n（你刚睡醒，迷迷糊糊的，睡了 ${sleptMinutes} 分钟。）`;
    const otherWake = await this.callOther(otherWakePrompt);
    this.log(`${otherName}：${otherWake}`); this._emit('other', otherWake);;
    this.session.recordTurn(otherWake, selfWake);
    // 睡醒 → 精力回升
    this.session.adjustMood({ energy: 40, warmth: 5 });

    // 继续聊几轮
    const rounds = this.cfg.sleep.continueAfterWake || 0;
    let lastSelf = selfWake;
    let lastOther = otherWake;
    const seen = new Set([selfWake, otherWake]);

    for (let i = 0; i < rounds; i++) {
      if (!this.session.isOnline().online) break;
      await this._sleep(this._randGap());
      try {
        const r = await this.callSelf(
          this.prompts.buildSelfPrompt(lastOther, [
            { role: 'self', text: lastSelf },
            { role: 'other', text: lastOther },
          ]),
        );
        if (r && !seen.has(r)) {
          seen.add(r);
          lastSelf = r;
          this.session.recordTurn(lastOther, r);
          this.log(`我：${r}`); this._emit('self', r);;
        }
      } catch { break; }

      await this._sleep(this._randGap());
      try {
        const r = await this.callOther(
          this.prompts.buildOtherPrompt(lastSelf, otherName, []),
        );
        if (r && !seen.has(r)) {
          seen.add(r);
          lastOther = r;
          this.session.recordTurn(r, lastSelf);
          this.log(`${otherName}：${r}`); this._emit('other', r);;
        }
      } catch { break; }
    }
    this.log('醒后对话结束');
  }

  /** 停止 */
  stop() {
    if (this.sleepTimer) {
      clearTimeout(this.sleepTimer);
      this.sleepTimer = null;
    }
    this.running = false;
  }
}
