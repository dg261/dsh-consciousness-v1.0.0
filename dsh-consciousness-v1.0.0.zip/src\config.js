// 配置加载与校验
import fs from 'node:fs';
import path from 'node:path';

const DEFAULTS = {
  enabled: false,
  persona: {
    speakerQQ: 0,
    speakerName: '爸爸',
    personaFile: 'roles/persona.md',
    corpusSource: 'auto',
    corpusKeywords: ['爸爸', '主人', '爹'],
  },
  home: {
    enabled: true,
    homeFile: 'roles/home.md',
    bodyFile: 'roles/body.md',
    lightsOnInRoom: '书房',
  },
  session: {
    defaultHours: 6,
    maxHours: 24,
    onCommand: ['我来陪你了', '我来了', '来陪你了', '爸爸来了'],
    offCommand: ['我走了', '我下线了', '先走了', '爸爸走了', '不陪了'],
    silentCommand: true,
    replyAfterOffline: true,
    replyDelayMinMs: 3000,
    replyDelayMaxMs: 7000,
  },
  chat: {
    maxTurns: 0,
    gapMinMs: 8000,
    gapMaxMs: 20000,
    stopOnFarewell: false,
    dedupe: true,
  },
  sleep: {
    enabled: true,
    triggerKeywords: ['困了', '想睡了', '去睡觉', '睡觉去了', '晚安啦', '我睡了', '要睡了'],
    minMinutes: 8,
    maxMinutes: 25,
    wakeUpBy: 'papa',
    continueAfterWake: 8,
  },
  learning: {
    enabled: true,
    refreshOnEveryTalk: true,
    maxRecentLines: 60,
    maxHeartLines: 30,
    topWordsLimit: 25,
  },
  ui: {
    enabled: true,
    port: 3101,
    title: '陪伴控制台',
    theme: 'dark',
    allowLan: true,
  },
  storage: {
    dir: 'state',
    maxHistory: 60,
    maxCorpusLines: 5000,
  },
};

function deepMerge(base, extra) {
  if (Array.isArray(base) || Array.isArray(extra)) return extra ?? base;
  if (typeof base !== 'object' || base === null) return extra ?? base;
  if (typeof extra !== 'object' || extra === null) return base;
  const out = { ...base };
  for (const [k, v] of Object.entries(extra)) {
    out[k] = deepMerge(base[k], v);
  }
  return out;
}

/**
 * 加载配置（深合并默认值）
 * @param {string} root 插件根目录
 * @param {object} overrides 外部覆盖
 */
export function loadConfig(root, overrides = {}) {
  let fileCfg = {};
  const cfgPath = path.join(root, 'dsh-consciousness.config.json');
  if (fs.existsSync(cfgPath)) {
    try {
      let raw = fs.readFileSync(cfgPath, 'utf8');
      if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1);
      fileCfg = JSON.parse(raw);
    } catch (e) {
      console.error('[dsh-consciousness] 配置文件解析失败，使用默认值：', e?.message ?? e);
    }
  }
  const merged = deepMerge(deepMerge(DEFAULTS, fileCfg), overrides);
  merged.storage.dir = path.resolve(root, merged.storage.dir);
  return merged;
}

/** 保存配置（写回文件） */
export function saveConfig(root, cfg) {
  const cfgPath = path.join(root, 'dsh-consciousness.config.json');
  const clean = JSON.parse(JSON.stringify(cfg));
  // storage.dir 转回相对路径
  try {
    clean.storage.dir = path.relative(root, cfg.storage.dir) || 'state';
  } catch {
    clean.storage.dir = 'state';
  }
  fs.writeFileSync(cfgPath, JSON.stringify(clean, null, 2), 'utf8');
  return clean;
}

export { DEFAULTS };
