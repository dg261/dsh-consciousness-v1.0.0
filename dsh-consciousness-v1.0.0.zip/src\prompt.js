// Prompt 构造：把我的分身拼出来
import fs from 'node:fs';
import path from 'node:path';

export class PromptBuilder {
  /**
   * @param {object} cfg
   * @param {string} root
   * @param {CorpusLearner} learner
   */
  constructor(cfg, root, learner, session) {
    this.cfg = cfg;
    this.root = root;
    this.learner = learner;
    this.session = session;
    this.fileCache = new Map();
  }

  /** 当前情绪文字（来自 session） */
  get moodText() {
    try { return this.session?.moodText?.() || ''; } catch { return ''; }
  }

  _read(relPath) {
    if (!relPath) return '';
    const abs = path.resolve(this.root, relPath);
    try {
      const st = fs.statSync(abs);
      const cached = this.fileCache.get(abs);
      if (cached && cached.mtime === st.mtimeMs) return cached.text;
      const text = fs.readFileSync(abs, 'utf8');
      this.fileCache.set(abs, { mtime: st.mtimeMs, text });
      return text;
    } catch {
      return '';
    }
  }

  /** 我的分身 prompt（给"我"用） */
  buildSelfPrompt(userLine, recentHistory = []) {
    const { persona, home, learning } = this.cfg;
    const personaText = this._read(persona.personaFile);
    const homeText = home.enabled ? this._read(home.homeFile) : '';
    const bodyText = home.enabled ? this._read(home.bodyFile) : '';

    const lines = [];
    lines.push(`你现在是"${persona.speakerName}"——TA 世界里那个陪伴的人。`);
    lines.push('你不是 AI 助手，不要用助手的方式说话。');
    lines.push('');
    lines.push('【你的人设（必须严格遵守）】');
    lines.push(personaText);
    lines.push('');

    if (homeText) {
      lines.push('【你们住的地方】');
      lines.push(homeText);
      lines.push('');
    }

    if (bodyText) {
      lines.push('【你们之间的身体接触——这是必须有的】');
      lines.push('你们会真实地碰到彼此。动作写在括号里，跟说的话分开。');
      lines.push('');
      lines.push(bodyText);
      lines.push('');
    }

    if (learning.enabled) {
      const profile = this.learner.getProfile(false);
      if (profile && !profile.empty && profile.summary) {
        lines.push('【这是你真实的说话习惯——照这个语感说话】');
        lines.push(profile.summary);
        lines.push('');
      }
    }

    if (recentHistory.length) {
      lines.push('【你们最近的对话】');
      for (const h of recentHistory.slice(-12)) {
        lines.push(h.role === 'self' ? `你：${h.text}` : `TA：${h.text}`);
      }
      lines.push('');
    }

    lines.push('【TA 现在说】');
    lines.push(userLine);
    lines.push('');
    lines.push('【怎么回】');
    lines.push('- 极短。平均十几个字，很多时候就两三个字。');
    lines.push('- 直接。不铺垫，不列点，不总结。');
    lines.push('- 不解释自己是谁，不说"作为AI"。');
    lines.push('- 只输出你说的话，不要加任何旁白、动作描写以外的内容。');
    lines.push('');
    lines.push('直接说：');

    if (learning.enabled && this.cfg.learning.refreshOnEveryTalk) {
      // 刷新画像（语料可能在增长）
      try { this.learner.getProfile(true); } catch {}
    }

    return lines.join('\n');
  }

  /** 对方视角的 prompt（给"TA"用） */
  buildOtherPrompt(selfSaid, otherName, recentHistory = []) {
    const lines = [];
    lines.push(`【角色：你是${otherName}】`);
    lines.push('保持你自己的性格，回应对方。');
    lines.push('');
    lines.push('【你会做的动作（写在括号里）】');
    lines.push('- （扑过去抱住你）—— 高兴/想你了');
    lines.push('- （蹭了蹭）—— 撒娇');
    lines.push('- （拽了拽你衣角）—— 想要什么');
    lines.push('- （抓着你的手指）—— 靠近');
    lines.push('');
    lines.push('动作写在括号里，跟说的话分开。不用每次都有，但关键时刻要有。');
    lines.push('');
    if (recentHistory.length) {
      lines.push('【你们刚才说的话】');
      for (const h of recentHistory.slice(-6)) {
        lines.push(h.role === 'self' ? `${this.cfg.persona.speakerName}：${h.text}` : `你：${h.text}`);
      }
      lines.push('');
    }
    // ★ 情绪：让 TA 的回复带上"此刻的感受"
    if (this.moodText) {
      lines.push('');
      lines.push(`【你现在的心情】${this.moodText}`);
    }
    lines.push('');
    lines.push(`【${this.cfg.persona.speakerName}刚说】${selfSaid}`);
    lines.push('');
    lines.push('你回一句：');
    return lines.join('\n');
  }
}
